import routes_user
import routes_projects
import routes_requests




"""
Usiamo decoratori per definire percorsi URL nella nostra istanza dell'applicazione.
I percorsi URL possono includere variabili nelle loro definizioni consentendoci di personalizzare
 le nostre query per ottenere le informazioni esatte richieste.
 Per passare una variabile all'interno di una route si usa : <tipo:nome_variabile>.
 Per chiamare una funzione di route si usa la funzione : url_for('nome_funzione_route')

"""





 
     
